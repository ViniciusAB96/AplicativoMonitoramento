﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monitoramento_RAM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chartRAM.Legends.Clear();
            chartRAM.Series["GraficoRAM"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            timer.Start();
        }
        UInt32 SizeinKB, SizeinMB, SizeinGB;
        double MemoriadDisponivel;


        private void timer_Tick(object sender, EventArgs e)
        {


            //Memória fisica do computador RAM
            string Query = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
            foreach (ManagementObject WniPART in searcher.Get())
            {
                SizeinKB = Convert.ToUInt32(WniPART.Properties["MaxCapacity"].Value);
                SizeinMB = SizeinKB / 1024;
                SizeinGB = SizeinMB / 1024;

                //    Console.WriteLine("Size in KB: {0}, Size in MB: {1}, Size in GB: {2}", SizeinKB, SizeinMB, SizeinGB + Environment.NewLine);
            }
            textTotalDeRAM.Text = SizeinGB.ToString() + " GBytes";


            //Current memory RAM of the computer.
            Console.WriteLine("Memória disponível para uso, sendo que essa memória é a memória RAM atual");
            System.Diagnostics.PerformanceCounter m_memoryCounter = new System.Diagnostics.PerformanceCounter();
            m_memoryCounter.CategoryName = "Memory";
            m_memoryCounter.CounterName = "Available MBytes";

            MemoriadDisponivel = m_memoryCounter.RawValue;

            if (MemoriadDisponivel > 1024)
            {
                MemoriadDisponivel = Math.Round(MemoriadDisponivel / 1024, 2);
                label4.Text = MemoriadDisponivel.ToString() + " Gbytes";
            }
            else
                label4.Text = MemoriadDisponivel.ToString() + " Mbytes";



            //chartRAM.Series.Add("GraficoRAM");

            if (chartRAM.Series[0].Points.Count > 10)
            {
                chartRAM.Series[0].Points.RemoveAt(0);
                chartRAM.Update();
            }

            chartRAM.Series[0].Points.AddY(MemoriadDisponivel);

        }


        private void checkEnable3D_CheckedChanged(object sender, EventArgs e)
        {
            if (checkEnable3D.Checked)
                chartRAM.ChartAreas[0].Area3DStyle.Enable3D = true;
            else
                chartRAM.ChartAreas[0].Area3DStyle.Enable3D = false;

        }
    }
}
