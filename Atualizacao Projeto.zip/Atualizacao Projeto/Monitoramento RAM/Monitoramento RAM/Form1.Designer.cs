﻿namespace Monitoramento_RAM
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chartRAM = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.textTotalDeRAM = new System.Windows.Forms.TextBox();
            this.checkEnable3D = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chartRAM)).BeginInit();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "RAM total";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Total de RAM";
            // 
            // chartRAM
            // 
            chartArea1.Name = "ChartArea1";
            this.chartRAM.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartRAM.Legends.Add(legend1);
            this.chartRAM.Location = new System.Drawing.Point(15, 52);
            this.chartRAM.Name = "chartRAM";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "GraficoRAM";
            this.chartRAM.Series.Add(series1);
            this.chartRAM.Size = new System.Drawing.Size(773, 366);
            this.chartRAM.TabIndex = 3;
            this.chartRAM.Text = "chart1";
            // 
            // textTotalDeRAM
            // 
            this.textTotalDeRAM.Enabled = false;
            this.textTotalDeRAM.Location = new System.Drawing.Point(12, 26);
            this.textTotalDeRAM.Name = "textTotalDeRAM";
            this.textTotalDeRAM.Size = new System.Drawing.Size(100, 20);
            this.textTotalDeRAM.TabIndex = 6;
            // 
            // checkEnable3D
            // 
            this.checkEnable3D.AutoSize = true;
            this.checkEnable3D.Location = new System.Drawing.Point(214, 26);
            this.checkEnable3D.Name = "checkEnable3D";
            this.checkEnable3D.Size = new System.Drawing.Size(81, 17);
            this.checkEnable3D.TabIndex = 7;
            this.checkEnable3D.Text = "Habilitar 3D";
            this.checkEnable3D.UseVisualStyleBackColor = true;
            this.checkEnable3D.CheckedChanged += new System.EventHandler(this.checkEnable3D_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(469, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "label4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 436);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkEnable3D);
            this.Controls.Add(this.textTotalDeRAM);
            this.Controls.Add(this.chartRAM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Monitoramento de RAM";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartRAM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartRAM;
        private System.Windows.Forms.TextBox textTotalDeRAM;
        private System.Windows.Forms.CheckBox checkEnable3D;
        private System.Windows.Forms.Label label4;
    }
}

