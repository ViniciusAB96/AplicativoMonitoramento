﻿using System;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Threading;
using System.Windows.Forms;

namespace Trafico_de_dados_Usando
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        long preBytesSend = 0;
        long preBytesRec = 0;
        long DSpeed, USpeed;
        double totalPorPagina = 0.0;
        double maiorValorMonitorado = 0.0;
        int minutosDecorridos = DateTime.Now.Minute;
        int segundosPercorridos= DateTime.Now.Second;

        private void Form1_Load(object sender, EventArgs e)
        {
            ChartUsoRede.Legends.Clear();
            ChartUsoRede.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            timer1.Start();           
        }

        private void Enable3D_CheckedChanged(object sender, EventArgs e)
        {
            if (Enable3D.Checked)
            {
                ChartUsoRede.ChartAreas[0].Area3DStyle.Enable3D = true;
            }
            else
            {
                ChartUsoRede.ChartAreas[0].Area3DStyle.Enable3D = false;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            IPv4InterfaceStatistics iFace;

            iFace = NetworkInterface.GetAllNetworkInterfaces()[0].GetIPv4Statistics();

            DSpeed = (iFace.BytesSent - preBytesSend) ;
            USpeed  = (iFace.BytesReceived - preBytesRec) / 1024;


            if (DSpeed / 1024 >= 1 && USpeed / 1024 < 1)
            {
                DSpeed = DSpeed / 1024;
                DawnLoadLabel.Text = String.Format(Math.Truncate((Double)DSpeed) + " Mb/s");
                UploadDataLabel.Text = String.Format(Math.Truncate((Double)USpeed) + " Kb/s");
            }
            else if (USpeed / 1024 >= 1 && DSpeed / 1024 < 1)
            {
                USpeed = USpeed / 1024;
                UploadDataLabel.Text = String.Format(Math.Round((Double)USpeed) + " Mb/s");
                DawnLoadLabel.Text = String.Format(Math.Round((Double)DSpeed) + " Kb/s");
            }

            else if (USpeed / 1024 >= 1 && DSpeed / 1024 >= 1)
            {
                DSpeed = DSpeed / 1024;
                USpeed = USpeed / 1024;
                DawnLoadLabel.Text = String.Format(Math.Round((Double)DSpeed) + " Mb/s");
                UploadDataLabel.Text = String.Format(Math.Round((Double)USpeed) + " Mb/s");
            }
            else 
            {
                DawnLoadLabel.Text = String.Format(Math.Round((Double)DSpeed) + " Kb/s");
                UploadDataLabel.Text = String.Format(Math.Round((Double)USpeed) + " Kb/s");
            }

            preBytesSend = NetworkInterface.GetAllNetworkInterfaces()[0].GetIPv4Statistics().BytesSent;
            preBytesRec = NetworkInterface.GetAllNetworkInterfaces()[0].GetIPv4Statistics().BytesReceived;

            totalPorPagina += Math.Truncate((Double)(preBytesRec - iFace.BytesReceived)) / 102.4;
            TotalPagina.Text = String.Format("{0:0.0}, Mbytes", (totalPorPagina/512));



            if (ChartUsoRede.Series[0].Points.Count > 10)//Se a contagem dos gráficos for maoir do que 5 eu tenho que remover o primeiro para que assim seja possível ser visualizado na tela
            {
                ChartUsoRede.Series[0].Points.RemoveAt(0);//estou removendo o primeiro ponto. O mais antigo.
                ChartUsoRede.Update(); //Faz com que a alteração seja visível.      
            }
            ChartUsoRede.Series[0].Points.AddY(Math.Round((Double)(DSpeed+USpeed)));

            minutosDecorridos = DateTime.Now.Minute;
            segundosPercorridos = DateTime.Now.Second;

            if ((segundosPercorridos == 0) && (minutosDecorridos % 2 == 0))
            {
                labelEnvio.Text = (Math.Round((Double)(DSpeed + USpeed))).ToString();//Posso utilizar esse método para enviar para o servidor as informações
            }
        }
    }
}

