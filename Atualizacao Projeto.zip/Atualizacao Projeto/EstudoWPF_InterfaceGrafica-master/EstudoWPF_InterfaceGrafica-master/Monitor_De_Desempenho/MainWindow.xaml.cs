﻿using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Monitor_De_Desempenho
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();
            SeriesCollection = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Espaço Utilizado",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(40) },
                    DataLabels = true
                },
                new PieSeries
                {
                    Title = "Espaço Livre",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(60)},
                    DataLabels = true
                }
            };
            DataContext = this;
            //ChartValues<double> values1Test = new ChartValues<double> { 20, 80};
            //  SerieEspacoLivre.Values = values1Test;
            //ChartUsoCPU.AddToView(values1Test);
            //  PointLabel = chartPoint => String.Format("{0} (1:P)", chartPoint.Y, chartPoint.Participation);
            //   Consumo consumo = new Consumo();
            //  DataContext = new ConsumoViewModel(consumo);
            //    ChartUsoDisco.Update(true, true);
            // CarregaSerieGrafico();
        }
        public SeriesCollection SeriesCollection { get; set; }



        private void GridBarraTitulo_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
        private void ButtonFechar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();//Fechando a aplicação.
        }

        private void CarregaSerieGrafico()
        {
            var r = new Random();
            var c = SeriesCollection.Count > 0 ? SeriesCollection[0].Values.Count : 5;

            var vals = new ChartValues<ObservableValue>();
            vals.Add(new ObservableValue(30));
            vals.Add(new ObservableValue(70));
            SeriesCollection.Add(new PieSeries
            {
                Values = vals
            });
        }

        private void ButtonDisco_Click(object sender, RoutedEventArgs e)
        {

        }
        private void ButtonRede_Click(object sender, RoutedEventArgs e)
        {
        }
        private void ButtonMemoriaRAM_Click(object sender, RoutedEventArgs e)
        {

        }
        private void ButtonCPU_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
