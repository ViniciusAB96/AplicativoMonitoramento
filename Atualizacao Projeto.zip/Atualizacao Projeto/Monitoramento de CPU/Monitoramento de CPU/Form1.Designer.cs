﻿namespace Monitoramento_de_CPU
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.chartCurrentTemperature = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label2 = new System.Windows.Forms.Label();
            this.textTemperature = new System.Windows.Forms.TextBox();
            this.timerCPU = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabTemperatura = new System.Windows.Forms.TabPage();
            this.tabFrequency = new System.Windows.Forms.TabPage();
            this.chartPorcentagemUsoCPU = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.textPorcentagemFrequencia = new System.Windows.Forms.TextBox();
            this.textFrequenciaMaxima = new System.Windows.Forms.TextBox();
            this.textFrequenciaAtual = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelNomeComputador = new System.Windows.Forms.Label();
            this.labelFabricante = new System.Windows.Forms.Label();
            this.labelBites = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chartCurrentTemperature)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabTemperatura.SuspendLayout();
            this.tabFrequency.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPorcentagemUsoCPU)).BeginInit();
            this.SuspendLayout();
            // 
            // chartCurrentTemperature
            // 
            chartArea7.Name = "ChartArea1";
            this.chartCurrentTemperature.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.chartCurrentTemperature.Legends.Add(legend7);
            this.chartCurrentTemperature.Location = new System.Drawing.Point(12, 49);
            this.chartCurrentTemperature.Name = "chartCurrentTemperature";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "serieTemperature";
            this.chartCurrentTemperature.Series.Add(series4);
            this.chartCurrentTemperature.Size = new System.Drawing.Size(734, 351);
            this.chartCurrentTemperature.TabIndex = 0;
            this.chartCurrentTemperature.Text = "chart1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Temperatura do Processador";
            // 
            // textTemperature
            // 
            this.textTemperature.Location = new System.Drawing.Point(161, 23);
            this.textTemperature.Name = "textTemperature";
            this.textTemperature.ReadOnly = true;
            this.textTemperature.Size = new System.Drawing.Size(119, 20);
            this.textTemperature.TabIndex = 3;
            // 
            // timerCPU
            // 
            this.timerCPU.Interval = 1000;
            this.timerCPU.Tick += new System.EventHandler(this.timerCPU_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabTemperatura);
            this.tabControl1.Controls.Add(this.tabFrequency);
            this.tabControl1.Location = new System.Drawing.Point(-4, 18);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(760, 446);
            this.tabControl1.TabIndex = 4;
            // 
            // tabTemperatura
            // 
            this.tabTemperatura.Controls.Add(this.chartCurrentTemperature);
            this.tabTemperatura.Controls.Add(this.textTemperature);
            this.tabTemperatura.Controls.Add(this.label2);
            this.tabTemperatura.Location = new System.Drawing.Point(4, 22);
            this.tabTemperatura.Name = "tabTemperatura";
            this.tabTemperatura.Padding = new System.Windows.Forms.Padding(3);
            this.tabTemperatura.Size = new System.Drawing.Size(752, 435);
            this.tabTemperatura.TabIndex = 0;
            this.tabTemperatura.Text = "Temperatura";
            this.tabTemperatura.UseVisualStyleBackColor = true;
            // 
            // tabFrequency
            // 
            this.tabFrequency.Controls.Add(this.chartPorcentagemUsoCPU);
            this.tabFrequency.Controls.Add(this.textPorcentagemFrequencia);
            this.tabFrequency.Controls.Add(this.textFrequenciaMaxima);
            this.tabFrequency.Controls.Add(this.textFrequenciaAtual);
            this.tabFrequency.Controls.Add(this.label4);
            this.tabFrequency.Controls.Add(this.label3);
            this.tabFrequency.Controls.Add(this.label1);
            this.tabFrequency.Location = new System.Drawing.Point(4, 22);
            this.tabFrequency.Name = "tabFrequency";
            this.tabFrequency.Padding = new System.Windows.Forms.Padding(3);
            this.tabFrequency.Size = new System.Drawing.Size(752, 420);
            this.tabFrequency.TabIndex = 1;
            this.tabFrequency.Text = "Frequencia";
            this.tabFrequency.UseVisualStyleBackColor = true;
            // 
            // chartPorcentagemUsoCPU
            // 
            chartArea8.Name = "ChartArea1";
            this.chartPorcentagemUsoCPU.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.chartPorcentagemUsoCPU.Legends.Add(legend8);
            this.chartPorcentagemUsoCPU.Location = new System.Drawing.Point(6, 60);
            this.chartPorcentagemUsoCPU.Name = "chartPorcentagemUsoCPU";
            this.chartPorcentagemUsoCPU.Size = new System.Drawing.Size(740, 364);
            this.chartPorcentagemUsoCPU.TabIndex = 6;
            this.chartPorcentagemUsoCPU.Text = "chart1";
            // 
            // textPorcentagemFrequencia
            // 
            this.textPorcentagemFrequencia.Enabled = false;
            this.textPorcentagemFrequencia.Location = new System.Drawing.Point(286, 19);
            this.textPorcentagemFrequencia.Name = "textPorcentagemFrequencia";
            this.textPorcentagemFrequencia.ReadOnly = true;
            this.textPorcentagemFrequencia.Size = new System.Drawing.Size(115, 20);
            this.textPorcentagemFrequencia.TabIndex = 5;
            // 
            // textFrequenciaMaxima
            // 
            this.textFrequenciaMaxima.Enabled = false;
            this.textFrequenciaMaxima.Location = new System.Drawing.Point(541, 19);
            this.textFrequenciaMaxima.Name = "textFrequenciaMaxima";
            this.textFrequenciaMaxima.ReadOnly = true;
            this.textFrequenciaMaxima.Size = new System.Drawing.Size(128, 20);
            this.textFrequenciaMaxima.TabIndex = 4;
            // 
            // textFrequenciaAtual
            // 
            this.textFrequenciaAtual.Enabled = false;
            this.textFrequenciaAtual.Location = new System.Drawing.Point(12, 19);
            this.textFrequenciaAtual.Name = "textFrequenciaAtual";
            this.textFrequenciaAtual.ReadOnly = true;
            this.textFrequenciaAtual.Size = new System.Drawing.Size(158, 20);
            this.textFrequenciaAtual.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(281, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Porcentagem do uso do processador";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(538, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Frequencia máxima da CPU";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Frequecia atual do Processador";
            // 
            // labelNomeComputador
            // 
            this.labelNomeComputador.AutoSize = true;
            this.labelNomeComputador.Location = new System.Drawing.Point(4, 2);
            this.labelNomeComputador.Name = "labelNomeComputador";
            this.labelNomeComputador.Size = new System.Drawing.Size(35, 13);
            this.labelNomeComputador.TabIndex = 7;
            this.labelNomeComputador.Text = "label5";
            // 
            // labelFabricante
            // 
            this.labelFabricante.AutoSize = true;
            this.labelFabricante.Location = new System.Drawing.Point(323, 2);
            this.labelFabricante.Name = "labelFabricante";
            this.labelFabricante.Size = new System.Drawing.Size(35, 13);
            this.labelFabricante.TabIndex = 8;
            this.labelFabricante.Text = "label6";
            // 
            // labelBites
            // 
            this.labelBites.AutoSize = true;
            this.labelBites.Location = new System.Drawing.Point(518, 2);
            this.labelBites.Name = "labelBites";
            this.labelBites.Size = new System.Drawing.Size(35, 13);
            this.labelBites.TabIndex = 9;
            this.labelBites.Text = "label5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 450);
            this.Controls.Add(this.labelBites);
            this.Controls.Add(this.labelFabricante);
            this.Controls.Add(this.labelNomeComputador);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartCurrentTemperature)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabTemperatura.ResumeLayout(false);
            this.tabTemperatura.PerformLayout();
            this.tabFrequency.ResumeLayout(false);
            this.tabFrequency.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPorcentagemUsoCPU)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartCurrentTemperature;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textTemperature;
        private System.Windows.Forms.Timer timerCPU;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabTemperatura;
        private System.Windows.Forms.TabPage tabFrequency;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPorcentagemUsoCPU;
        private System.Windows.Forms.TextBox textPorcentagemFrequencia;
        private System.Windows.Forms.TextBox textFrequenciaMaxima;
        private System.Windows.Forms.TextBox textFrequenciaAtual;
        private System.Windows.Forms.Label labelNomeComputador;
        private System.Windows.Forms.Label labelFabricante;
        private System.Windows.Forms.Label labelBites;
    }
}

