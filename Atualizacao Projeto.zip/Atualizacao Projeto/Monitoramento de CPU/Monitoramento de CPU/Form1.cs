﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;

using System.Management;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Monitoramento_de_CPU
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PreencheCabecalho();
            chartPorcentagemUsoCPU.Legends.Clear();
            chartCurrentTemperature.Legends.Clear();
            chartCurrentTemperature.Series["serieTemperature"].ChartType = SeriesChartType.Line;
            chartPorcentagemUsoCPU.Series.Add("GraficoPorcentagemUso");
            chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].ChartType = SeriesChartType.Line;
            RecuperaFrequenciaProcessador();
            timerCPU.Start();
        }
        double temperatura, temperaturaEmCelsios, frequenciaMaxima, porcentagemUso, teste =0;
        //long firstValue = 0;
        String testeTempoEmMilisegundos;
     
        CounterSample secondValue;

        private void timerCPU_Tick(object sender, EventArgs e)
        {
            temperatura = 0;
            int contador = 0;
            teste = 0;


            PerformanceCounter _cpuCounter = new PerformanceCounter("Processor Information", "% Processor Utility", "_Total");
            CounterSample firstValue = _cpuCounter.NextSample();

            ManagementClass processClass = new ManagementClass(@"\root\cimv2:Win32_TemperatureProbe");

            foreach (ManagementObject service in processClass.GetInstances())
            {
                Console.WriteLine("Temperatura da  CPU e GPU na sequencia");
                Console.WriteLine("Valor da temperaturan vida do TemperaturaProbe: " + service.GetPropertyValue("Accuracy"));

                temperatura = Convert.ToInt32(service.GetPropertyValue("Accuracy"));
                temperaturaEmCelsios = ((temperatura / 100) - 273.15);

                textTemperature.Text = temperaturaEmCelsios.ToString() + " ºC";//Estou retornando a temperatura máxima e não a atual
           }



            
         //   labelBites.Text = Environment.SystemPageSize.ToString();
            //Environment.UserName; Retorna o nome do usuário que está logado na máquina
           
            ConstroiGraficoTemperatura();

            ManagementObjectSearcher pesquisa = new ManagementObjectSearcher("SELECT PageFileUsage FROM Win32_Process");
            ManagementObjectCollection objcts = pesquisa.Get();
            foreach (ManagementObject objc in objcts)
            {
                teste = teste + Math.Round(Convert.ToDouble(objc["PageFileUsage"]) / 1024, 2);
                contador++;
            }
            //   Thread.Sleep(500);//Eu preciso comparar os dois valores para que posteriormente eu consiga 
            labelBites.Text = Math.Round((teste/1024),2).ToString();
            secondValue = _cpuCounter.NextSample();

            string cpuUsageReal = CounterSample.Calculate(firstValue, secondValue).ToString("0.0");
            porcentagemUso = CounterSample.Calculate(firstValue, secondValue);
            textPorcentagemFrequencia.Text = Math.Round(porcentagemUso, 2).ToString() + " %";
            ConstroiGraficoFrequencia();
            Process[] proc = Process.GetProcesses();
            foreach(Process pr in proc)
            {
                //MessageBox.Show(pr.ToString());
                testeTempoEmMilisegundos = (pr.TotalProcessorTime.Duration().Seconds.ToString()) + Environment.NewLine ;
            }
            MessageBox.Show(testeTempoEmMilisegundos);
            //  Console.WriteLine("Frequencia do processador {0}, load {1}", cpuUsage, load);//Funciona
            //Console.WriteLine("Quantide CPUs: {0}", cpus);

            //    Console.WriteLine(cpuUsageReal);//Funciona para pegar o uso da CPU em %, posteriormente eu posso utilizar esse valor para que

        }
        public void ConstroiGraficoTemperatura()
        {
            chartCurrentTemperature.Legends.Clear();

            chartCurrentTemperature.Legends.Add(new Legend("Temperatura"));
            chartCurrentTemperature.Legends["Temperatura"].LegendStyle = LegendStyle.Table;
            chartCurrentTemperature.Legends["Temperatura"].Docking = Docking.Bottom;
            chartCurrentTemperature.Legends["Temperatura"].Alignment = StringAlignment.Center;
            chartCurrentTemperature.Legends["Temperatura"].Title = "CPU:";
            chartCurrentTemperature.Legends["Temperatura"].BorderColor = Color.Black;
            chartCurrentTemperature.Series["serieTemperature"].LegendText = "Temperatura da CPU";

            // chartCurrentTemperature.Series["serieTemperature"].Points.AddXY(System.DateTime.Now.Second.ToString() + " s", temperaturaEmCelsios);

            chartCurrentTemperature.Series["serieTemperature"].Legend = "Temperatura";

            if (chartCurrentTemperature.Series["serieTemperature"].Points.Count > 6)
            {
                chartCurrentTemperature.Series["serieTemperature"].Points.RemoveAt(0);
                chartCurrentTemperature.Update();
            }
            chartCurrentTemperature.Series["serieTemperature"].Points.AddXY(System.DateTime.Now.Second.ToString() + " s", temperaturaEmCelsios);
        }
        public void ConstroiGraficoFrequencia()
        {
            chartPorcentagemUsoCPU.Legends.Clear();
            chartPorcentagemUsoCPU.Legends.Add(new Legend("Porcentagem"));
            chartPorcentagemUsoCPU.Legends["Porcentagem"].LegendStyle = LegendStyle.Table;
            chartPorcentagemUsoCPU.Legends["Porcentagem"].Docking = Docking.Bottom;
            chartPorcentagemUsoCPU.Legends["Porcentagem"].Alignment = StringAlignment.Center;
            chartPorcentagemUsoCPU.Legends["Porcentagem"].Title = "Porcentagem de Uso máximo da CPU";
            chartPorcentagemUsoCPU.Legends["Porcentagem"].BorderColor = Color.Black;
            chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].LegendText = "Porcentagem do uso total da CPU";

            //     chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].Points.AddXY(System.DateTime.Now.Second.ToString() +" s", porcentagemUso);
            chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].Legend = "Porcentagem";

            if (chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].Points.Count > 6)
            {
                chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].Points.RemoveAt(0);
                chartPorcentagemUsoCPU.Update();
            }

            chartPorcentagemUsoCPU.Series["GraficoPorcentagemUso"].Points.AddXY(System.DateTime.Now.Second.ToString() + " s", porcentagemUso);


        }
        public void RecuperaFrequenciaProcessador()
        {
            ManagementObjectSearcher pesquisaParticao = new ManagementObjectSearcher("SELECT maxclockspeed FROM Win32_Processor");
            ManagementObjectCollection retornoPesquisa = pesquisaParticao.Get();
            if (retornoPesquisa.Count != 1)
            {
                throw new Exception("Mais de uma frequencia encontrada no computador, ou a frequencia não pode ser obtida");
            }
            foreach (ManagementObject objc in retornoPesquisa)
            {
                frequenciaMaxima = Math.Round(Convert.ToDouble(objc["maxclockspeed"]) / 1000, 2);
            }
            //frequenciaMaxima = retornoPesquisa["maxclockspeed"].ToString();
            textFrequenciaMaxima.Text = String.Format(frequenciaMaxima + " GHz");
        }
        public void PreencheCabecalho()
        {
            ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("SELECT datawidth, name, manufacturer FROM Win32_Processor");

            ManagementObjectCollection objCol = searcher2.Get();
            foreach (ManagementObject mgtObject in objCol)
            {
                labelNomeComputador.Text = "Chipset: " + mgtObject["name"].ToString();
                labelFabricante.Text = "Modelo: " + mgtObject["manufacturer"].ToString();
                labelBites.Text = mgtObject["datawidth"].ToString() + " Bits";
            }

        }
    }
}
