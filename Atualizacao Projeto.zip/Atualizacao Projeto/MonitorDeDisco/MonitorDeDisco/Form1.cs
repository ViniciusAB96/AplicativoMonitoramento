﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace MonitorDeDisco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ArrayList particoes = new ArrayList();
        double tamanhoDaPaticaoGB = 0;
        double espacoDisponivelGB = 0;
        double porcentagemUso, porcentagemLivre;
        const int VALORPARAGB = 1073741824;

        string discoSelecionado;



        private void Form1_Load(object sender, EventArgs e)
        {


            PreencheComboDiscos();

            timeGrafico.Start();

        }

        private void comboDiscos_SelectedIndexChanged(object sender, EventArgs e)
        {
            //comboDiscos.SelectedText = comboDiscos.GetItemText(comboDiscos.)
            discoSelecionado = comboDiscos.SelectedItem.ToString();
        }

        private void Enable3D_CheckedChanged(object sender, EventArgs e)
        {
            if (Enable3D.Checked)
            {
                ChartDiscos.ChartAreas[0].Area3DStyle.Enable3D = true;
            }
            else
            {
                ChartDiscos.ChartAreas[0].Area3DStyle.Enable3D = false;
            }
        }

        private void timeGrafico_Tick(object sender, EventArgs e)
        {
            if (discoSelecionado != null)
            {
                ManagementObjectSearcher FisicalMemory = new ManagementObjectSearcher("Select DeviceID, VolumeName, ProviderName, Size, FreeSpace FROM Win32_LogicalDisk where DeviceID = '" + discoSelecionado + "'");
                ManagementObjectCollection retornoDoDisco = FisicalMemory.Get();//pega o retorno do select que está atuando sobre WMI

                foreach (ManagementObject retorno in retornoDoDisco)
                {
                    tamanhoDaPaticaoGB = Math.Round(Convert.ToDouble(retorno["Size"]) / VALORPARAGB, 3);
                    espacoDisponivelGB = Math.Round(Convert.ToDouble(retorno["FreeSpace"]) / VALORPARAGB, 3);

                    if (tamanhoDaPaticaoGB > 1024)
                    {
                        textEspacoTotal.Text = Math.Round((tamanhoDaPaticaoGB / 1024), 2).ToString() + " TBytes";
                        if (espacoDisponivelGB > 1024)
                        {
                            textEspacoLivre.Text = Math.Round((espacoDisponivelGB / 1024), 2).ToString() + " TBytes";
                        }
                        else
                        {
                            textEspacoLivre.Text = Math.Round(espacoDisponivelGB, 2).ToString() + " GBytes";
                        }
                        if (((tamanhoDaPaticaoGB - espacoDisponivelGB) / 1024) > 1)
                        {
                            textEspacoUtilizado.Text = Math.Round(((tamanhoDaPaticaoGB - espacoDisponivelGB) / 1024), 2).ToString() + " TBytes";
                        }
                    }
                    else
                    {
                        textEspacoTotal.Text = (tamanhoDaPaticaoGB).ToString() + " GBytes";
                        textEspacoLivre.Text = espacoDisponivelGB.ToString() + " GBytes";
                        textEspacoUtilizado.Text = (tamanhoDaPaticaoGB - espacoDisponivelGB).ToString() + " GBytes";
                    }
                    porcentagemLivre = Math.Truncate((espacoDisponivelGB / tamanhoDaPaticaoGB) * 100);
                    porcentagemUso = Math.Truncate(100 - porcentagemLivre);
                    
                    //Verificar como consertar o Label desse gráfico
                    ChartDiscos.Series.Clear();
                    ChartDiscos.Legends.Clear();

                    ChartDiscos.Legends.Add(new Legend("Porcentagens"));
                    ChartDiscos.Legends["Porcentagens"].LegendStyle = LegendStyle.Table;
                    ChartDiscos.Legends["Porcentagens"].Docking = Docking.Bottom;
                    ChartDiscos.Legends["Porcentagens"].Alignment = StringAlignment.Center;
                    ChartDiscos.Legends["Porcentagens"].Title = "Porcentagens de utilização do Disco:  " + discoSelecionado;
                    ChartDiscos.Legends["Porcentagens"].BorderColor = Color.Black;

                    ChartDiscos.Series.Add("GraficoPizza");
                    ChartDiscos.Series["GraficoPizza"].ChartType = SeriesChartType.Doughnut;

                    ChartDiscos.Series["GraficoPizza"].Points.AddXY("Livre: " + porcentagemLivre + "%", porcentagemLivre);
                    ChartDiscos.Series["GraficoPizza"].Points.AddXY("Em uso: " + porcentagemUso + "%", porcentagemUso);


                    ChartDiscos.Series["GraficoPizza"].Legend = "Porcentagens";

                }
            }
            else {
                ChartDiscos.Series.Clear();
                ChartDiscos.Legends.Clear();
            }
        }
        
        public void PreencheComboDiscos()
        {
            ManagementObjectSearcher Discos = new ManagementObjectSearcher("Select DeviceID FROM Win32_LogicalDisk where Size != null ");
            ManagementObjectCollection retornoDiscos = Discos.Get();//pega o retorno do select que está atuando sobre WMI
            foreach (ManagementObject retorno in retornoDiscos)
            {
                comboDiscos.Items.Add(retorno["DeviceID"].ToString());
            }
        }
    }
}
