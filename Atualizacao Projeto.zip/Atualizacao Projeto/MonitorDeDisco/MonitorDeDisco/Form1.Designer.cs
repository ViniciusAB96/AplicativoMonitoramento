﻿namespace MonitorDeDisco
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.comboDiscos = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textEspacoLivre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textEspacoUtilizado = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textEspacoTotal = new System.Windows.Forms.TextBox();
            this.Enable3D = new System.Windows.Forms.CheckBox();
            this.ChartDiscos = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label4 = new System.Windows.Forms.Label();
            this.timeGrafico = new System.Windows.Forms.Timer(this.components);
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartDiscos)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.comboDiscos);
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.textEspacoLivre);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.textEspacoUtilizado);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.textEspacoTotal);
            this.flowLayoutPanel1.Controls.Add(this.Enable3D);
            this.flowLayoutPanel1.Controls.Add(this.ChartDiscos);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(733, 426);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // comboDiscos
            // 
            this.comboDiscos.FormattingEnabled = true;
            this.comboDiscos.Location = new System.Drawing.Point(3, 3);
            this.comboDiscos.Name = "comboDiscos";
            this.comboDiscos.Size = new System.Drawing.Size(121, 21);
            this.comboDiscos.TabIndex = 0;
            this.comboDiscos.SelectedIndexChanged += new System.EventHandler(this.comboDiscos_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Espaço Livre no Disco";
            // 
            // textEspacoLivre
            // 
            this.textEspacoLivre.Enabled = false;
            this.textEspacoLivre.Location = new System.Drawing.Point(250, 3);
            this.textEspacoLivre.Name = "textEspacoLivre";
            this.textEspacoLivre.Size = new System.Drawing.Size(94, 20);
            this.textEspacoLivre.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(350, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Espaço Ocupado";
            // 
            // textEspacoUtilizado
            // 
            this.textEspacoUtilizado.Enabled = false;
            this.textEspacoUtilizado.Location = new System.Drawing.Point(446, 3);
            this.textEspacoUtilizado.Name = "textEspacoUtilizado";
            this.textEspacoUtilizado.Size = new System.Drawing.Size(100, 20);
            this.textEspacoUtilizado.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(552, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Espaço Total";
            // 
            // textEspacoTotal
            // 
            this.textEspacoTotal.Enabled = false;
            this.textEspacoTotal.Location = new System.Drawing.Point(628, 3);
            this.textEspacoTotal.Name = "textEspacoTotal";
            this.textEspacoTotal.Size = new System.Drawing.Size(100, 20);
            this.textEspacoTotal.TabIndex = 7;
            // 
            // Enable3D
            // 
            this.Enable3D.AutoSize = true;
            this.Enable3D.Location = new System.Drawing.Point(3, 30);
            this.Enable3D.Name = "Enable3D";
            this.Enable3D.Size = new System.Drawing.Size(80, 17);
            this.Enable3D.TabIndex = 8;
            this.Enable3D.Text = "checkBox1";
            this.Enable3D.UseVisualStyleBackColor = true;
            this.Enable3D.CheckedChanged += new System.EventHandler(this.Enable3D_CheckedChanged);
            // 
            // ChartDiscos
            // 
            chartArea1.Name = "ChartArea1";
            this.ChartDiscos.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.ChartDiscos.Legends.Add(legend1);
            this.ChartDiscos.Location = new System.Drawing.Point(3, 53);
            this.ChartDiscos.Name = "ChartDiscos";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.ChartDiscos.Series.Add(series1);
            this.ChartDiscos.Size = new System.Drawing.Size(722, 376);
            this.ChartDiscos.TabIndex = 2;
            this.ChartDiscos.Text = "chart1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, -1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Disco";
            // 
            // timeGrafico
            // 
            this.timeGrafico.Tick += new System.EventHandler(this.timeGrafico_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Monitor de Storage";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartDiscos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ComboBox comboDiscos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textEspacoLivre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textEspacoUtilizado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textEspacoTotal;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartDiscos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox Enable3D;
        private System.Windows.Forms.Timer timeGrafico;
    }
}

