﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace AppGerenciadorDeHardware
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }
        //retirar e colocar em uma classe separada, contendo os objetos do Disco
        ArrayList particoes = new ArrayList();
        double tamanhoDaPaticaoGB = 0;
        double espacoDisponivelGB = 0;
        double porcentagemUso, porcentagemLivre;
        const int VALORPARAGB = 1073741824;

        UInt32 SizeinKB, SizeinMB, SizeinGB;
        double MemoriadDisponivel;

        string discoSelecionado;


        private void Form1_Load(object sender, EventArgs e)
        {
            chartDiscos.ChartAreas[0].Area3DStyle.Enable3D = true;
            PreencheComboDiscosECarregaPrimeiro();
        }

        private void buttRAM_Click(object sender, EventArgs e)
        {
            timerDiscos.Start();
            panelEscolha.Height = butRAM.Height;
            panelEscolha.Top = butRAM.Top;
            panelDiscos.SendToBack();
            panelRAM.BringToFront();
            //  chartRAM.Series["GraficoRAM"].ChartType = SeriesChartType.Line;
            chartRAM.BackColor = Color.Transparent;
            chartRAM.Legends.Clear();
            RetornaMaximoMemoriaPermitido();
            RetornaInformacoesMemoria();
            timerRAM.Start();
        }

        private void comboDiscos_SelectedIndexChanged(object sender, EventArgs e)
        {
            discoSelecionado = comboDiscos.SelectedItem.ToString();
        }

        private void butDiscos_Click(object sender, EventArgs e)
        {
            timerRAM.Stop();
            panelEscolha.Height = butDiscos.Height;
            panelEscolha.Top = butDiscos.Top;
            comboDiscos.SelectedIndex = 0;
            panelDiscos.BringToFront();
            panelRAM.SendToBack();
            timerDiscos.Start();
        }

        private void butRede_Click(object sender, EventArgs e)
        {
            timerDiscos.Stop();
            panelEscolha.Height = butRede.Height;
            panelEscolha.Top = butRede.Top;
        }

        private void butCPU_Click(object sender, EventArgs e)
        {
            panelEscolha.Height = butCPU.Height;
            panelEscolha.Top = butCPU.Top;
        }
        private void butClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        #region Controles do monitoramento de Discos
        private void timerPrincipal_Tick(object sender, EventArgs e)
        {

            ManagementObjectSearcher FisicalMemory = new ManagementObjectSearcher("Select DeviceID, VolumeName, ProviderName, Size, FreeSpace FROM Win32_LogicalDisk where DeviceID = '" + discoSelecionado + "'");
            ManagementObjectCollection retornoDoDisco = FisicalMemory.Get();//pega o retorno do select que está atuando sobre WMI

            foreach (ManagementObject retorno in retornoDoDisco)
            {
                tamanhoDaPaticaoGB = Math.Round(Convert.ToDouble(retorno["Size"]) / VALORPARAGB, 3);
                espacoDisponivelGB = Math.Round(Convert.ToDouble(retorno["FreeSpace"]) / VALORPARAGB, 3);

                if (tamanhoDaPaticaoGB > 1024)
                {
                    labelEspacoTotal.Text = Math.Round((tamanhoDaPaticaoGB / 1024), 2).ToString() + " TBytes";
                    if (espacoDisponivelGB > 1024)
                    {
                        labelEspacoLivre.Text = Math.Round((espacoDisponivelGB / 1024), 2).ToString() + " TBytes";
                    }
                    else
                    {
                        labelEspacoLivre.Text = Math.Round(espacoDisponivelGB, 2).ToString() + " GBytes";
                    }
                    if (((tamanhoDaPaticaoGB - espacoDisponivelGB) / 1024) > 1)
                    {
                        labelEspacoUtilizado.Text = Math.Round(((tamanhoDaPaticaoGB - espacoDisponivelGB) / 1024), 2).ToString() + " TBytes";
                    }
                }
                else
                {
                    labelEspacoTotal.Text = (tamanhoDaPaticaoGB).ToString() + " GBytes";
                    labelEspacoLivre.Text = espacoDisponivelGB.ToString() + " GBytes";
                    labelEspacoUtilizado.Text = (tamanhoDaPaticaoGB - espacoDisponivelGB).ToString() + " GBytes";
                }
                porcentagemLivre = Math.Truncate((espacoDisponivelGB / tamanhoDaPaticaoGB) * 100);
                porcentagemUso = Math.Truncate(100 - porcentagemLivre);

                //Verificar como consertar o Label desse gráfico
                chartDiscos.Series.Clear();
                chartDiscos.Legends.Clear();

                chartDiscos.Legends.Add(new Legend("Porcentagens"));
                chartDiscos.Legends["Porcentagens"].LegendStyle = LegendStyle.Column;
                chartDiscos.Legends["Porcentagens"].Docking = Docking.Right;
                chartDiscos.Legends["Porcentagens"].Alignment = StringAlignment.Center;
                chartDiscos.Legends["Porcentagens"].Title = "Porcentagens de utilização do Disco:  " + discoSelecionado;
                chartDiscos.Legends["Porcentagens"].BorderColor = Color.White;
                chartDiscos.Legends["Porcentagens"].BackColor = Color.Transparent;
                chartDiscos.Legends["Porcentagens"].TitleForeColor = Color.WhiteSmoke;


                chartDiscos.Series.Add("GraficoPizza");
                chartDiscos.Series["GraficoPizza"].ChartType = SeriesChartType.Doughnut;

                chartDiscos.Series["GraficoPizza"].Points.AddXY("Livre: " + porcentagemLivre + "%", porcentagemLivre);
                chartDiscos.Series["GraficoPizza"].Points.AddXY("Em uso: " + porcentagemUso + "%", porcentagemUso);


                chartDiscos.Series["GraficoPizza"].Legend = "Porcentagens";

                chartDiscos.BackColor = Color.Transparent;
            }
        }

        private void panelRAM_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboDiscos_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            discoSelecionado = comboDiscos.SelectedItem.ToString();
        }


        public void PreencheComboDiscosECarregaPrimeiro()
        {
            ManagementObjectSearcher Discos = new ManagementObjectSearcher("Select DeviceID FROM Win32_LogicalDisk where Size != null ");
            ManagementObjectCollection retornoDiscos = Discos.Get();//pega o retorno do select que está atuando sobre WMI
            foreach (ManagementObject retorno in retornoDiscos)
            {
                comboDiscos.Items.Add(retorno["DeviceID"].ToString());
            }

        }
        #endregion

        #region Controles do monitoramento da RAM

        private void timerRAM_Tick(object sender, EventArgs e)
        {
            chartRAM.Legends.Clear();

            chartRAM.Series["GraficoRAM"].ChartType = SeriesChartType.Line;

            //Memória fisica do computador RAM
            string Query = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
            foreach (ManagementObject WniPART in searcher.Get())
            {
                SizeinKB = Convert.ToUInt32(WniPART.Properties["MaxCapacity"].Value);
                SizeinMB = SizeinKB / 1024;
                SizeinGB = SizeinMB / 1024;

            }
            textTotalDeRAM.Text = SizeinGB.ToString() + " GBytes";


            //Current memory RAM of the computer.
            Console.WriteLine("Memória disponível para uso, sendo que essa memória é a memória RAM atual");
            System.Diagnostics.PerformanceCounter m_memoryCounter = new System.Diagnostics.PerformanceCounter();
            m_memoryCounter.CategoryName = "Memory";
            m_memoryCounter.CounterName = "Available MBytes";

            MemoriadDisponivel = m_memoryCounter.RawValue;

            if (MemoriadDisponivel > 1024)
            {
                MemoriadDisponivel = Math.Round(MemoriadDisponivel / 1024, 2);
                textMemoriaDisponivel.Text = MemoriadDisponivel.ToString() + " Gbytes";
                textRAMUtilizada.Text = (SizeinGB - MemoriadDisponivel).ToString() + " Gbytes";

            }
            else
            {
                textMemoriaDisponivel.Text = MemoriadDisponivel.ToString() + " Mbytes";
                textRAMUtilizada.Text = Math.Round(((SizeinMB - MemoriadDisponivel) / 1024), 2).ToString() + " Mbytes";
            }

            if (chartRAM.Series["GraficoRAM"].Points.Count > 10)
            {
                chartRAM.Series["GraficoRAM"].Points.RemoveAt(0);
                chartRAM.Update();
            }

            chartRAM.Series["GraficoRAM"].Points.AddXY(DateTime.Now.Second + " s", MemoriadDisponivel);

        }

        public void RetornaInformacoesMemoria()
        {
            string Query = "SELECT Tag, DeviceLocator, Capacity, PartNumber, SerialNumber, Speed, HotSwappable FROM Win32_PhysicalMemory";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
            List<string> informacoesDaRAM;
            int counter = 0;
            double capacidadeDaMemoriaEmGB;

            foreach (ManagementObject retorno in searcher.Get())
            {
                informacoesDaRAM = new List<string>();
                informacoesDaRAM.Add(retorno["Tag"].ToString());
                informacoesDaRAM.Add(retorno["DeviceLocator"].ToString());
                capacidadeDaMemoriaEmGB = Convert.ToDouble(retorno["Capacity"]) / VALORPARAGB;
                informacoesDaRAM.Add(Math.Round(capacidadeDaMemoriaEmGB, 2).ToString() + " Gbytes");
                informacoesDaRAM.Add(retorno["PartNumber"].ToString());
                informacoesDaRAM.Add(retorno["SerialNumber"].ToString());
                informacoesDaRAM.Add(retorno["Speed"].ToString() + " MHz");
                if (retorno["HotSwappable"] == null)
                    informacoesDaRAM.Add(String.Format("Não realiza."));
                else
                    informacoesDaRAM.Add("Realiza.");

                dataGridInformacoesMemoria.Rows.Add(informacoesDaRAM.ToArray());

                counter++;

            }
        }

        public void RetornaMaximoMemoriaPermitido()
        {
            double valorMaximoDeRamPermitido;
            string Query = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
            foreach (ManagementObject retorno in searcher.Get())
            {
                if (searcher.Get().Count > 1)
                {
                    MessageBox.Show("Erro na capacidade máxima permitada pela máquina, a pesquisa está devolvendo mais do que um valor");
                }
                valorMaximoDeRamPermitido = Convert.ToDouble(retorno["MaxCapacity"]) / 1048576;
                textMaximoDeMemoria.Text = valorMaximoDeRamPermitido.ToString() + " Gbytes";
            }

        }

        #endregion
    }
}

