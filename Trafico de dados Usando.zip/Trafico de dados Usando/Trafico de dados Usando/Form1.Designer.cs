﻿namespace Trafico_de_dados_Usando
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.DownloadLabel = new System.Windows.Forms.Label();
            this.UploadDataLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TotalPagina = new System.Windows.Forms.Label();
            this.ChartUsoRede = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Enable3D = new System.Windows.Forms.CheckBox();
            this.labelEnvio = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ChartUsoRede)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // DownloadLabel
            // 
            this.DownloadLabel.AutoSize = true;
            this.DownloadLabel.Location = new System.Drawing.Point(136, 21);
            this.DownloadLabel.Name = "DownloadLabel";
            this.DownloadLabel.Size = new System.Drawing.Size(35, 13);
            this.DownloadLabel.TabIndex = 0;
            this.DownloadLabel.Text = "label1";
            // 
            // UploadDataLabel
            // 
            this.UploadDataLabel.AutoSize = true;
            this.UploadDataLabel.Location = new System.Drawing.Point(136, 44);
            this.UploadDataLabel.Name = "UploadDataLabel";
            this.UploadDataLabel.Size = new System.Drawing.Size(35, 13);
            this.UploadDataLabel.TabIndex = 1;
            this.UploadDataLabel.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Download";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Upload";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Total";
            // 
            // TotalPagina
            // 
            this.TotalPagina.AutoSize = true;
            this.TotalPagina.Location = new System.Drawing.Point(290, 21);
            this.TotalPagina.Name = "TotalPagina";
            this.TotalPagina.Size = new System.Drawing.Size(35, 13);
            this.TotalPagina.TabIndex = 5;
            this.TotalPagina.Text = "label4";
            // 
            // ChartUsoRede
            // 
            chartArea3.Name = "ChartArea1";
            this.ChartUsoRede.ChartAreas.Add(chartArea3);
            this.ChartUsoRede.Dock = System.Windows.Forms.DockStyle.Bottom;
            legend3.Name = "Legend1";
            this.ChartUsoRede.Legends.Add(legend3);
            this.ChartUsoRede.Location = new System.Drawing.Point(0, 74);
            this.ChartUsoRede.Name = "ChartUsoRede";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.ChartUsoRede.Series.Add(series3);
            this.ChartUsoRede.Size = new System.Drawing.Size(532, 300);
            this.ChartUsoRede.TabIndex = 6;
            this.ChartUsoRede.Text = "Uso da Rede";
            // 
            // Enable3D
            // 
            this.Enable3D.AutoSize = true;
            this.Enable3D.Location = new System.Drawing.Point(416, 13);
            this.Enable3D.Name = "Enable3D";
            this.Enable3D.Size = new System.Drawing.Size(107, 17);
            this.Enable3D.TabIndex = 7;
            this.Enable3D.Text = "Ativar Grafico 3D";
            this.Enable3D.UseVisualStyleBackColor = true;
            this.Enable3D.CheckedChanged += new System.EventHandler(this.Enable3D_CheckedChanged);
            // 
            // labelEnvio
            // 
            this.labelEnvio.AutoSize = true;
            this.labelEnvio.Location = new System.Drawing.Point(293, 55);
            this.labelEnvio.Name = "labelEnvio";
            this.labelEnvio.Size = new System.Drawing.Size(35, 13);
            this.labelEnvio.TabIndex = 8;
            this.labelEnvio.Text = "label4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 374);
            this.Controls.Add(this.labelEnvio);
            this.Controls.Add(this.Enable3D);
            this.Controls.Add(this.ChartUsoRede);
            this.Controls.Add(this.TotalPagina);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UploadDataLabel);
            this.Controls.Add(this.DownloadLabel);
            this.Name = "Form1";
            this.Text = "Monitor do uso de Banda";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ChartUsoRede)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label DownloadLabel;
        private System.Windows.Forms.Label UploadDataLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label TotalPagina;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartUsoRede;
        private System.Windows.Forms.CheckBox Enable3D;
        private System.Windows.Forms.Label labelEnvio;
    }
}

