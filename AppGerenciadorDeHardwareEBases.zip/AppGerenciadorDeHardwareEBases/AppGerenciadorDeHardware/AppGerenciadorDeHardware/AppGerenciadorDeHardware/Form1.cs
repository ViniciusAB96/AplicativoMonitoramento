﻿using AppGerenciadorDeHardware.ClassesWMI;
using AppGerenciadorDeHardware.VOs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace AppGerenciadorDeHardware
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }
        //retirar e colocar em uma classe separada, contendo os objetos do Disco
        Querys pesquisas = new Querys();
        ArrayList particoes = new ArrayList();
        double tamanhoDaPaticaoGB = 0;
        double espacoDisponivelGB = 0;
        double porcentagemUso, porcentagemLivre;
        const int VALORPARAGB = 1073741824;

        // UInt32 SizeinKB, SizeinMB, SizeinGB;
        double MemoriadDisponivel;
        int counter = 0;
        string discoSelecionado;


        private void Form1_Load(object sender, EventArgs e)
        {
            chartDiscos.ChartAreas[0].Area3DStyle.Enable3D = true;
            PreencheComboDiscosECarregaPrimeiro();
        }

        private void ButtRAM_Click(object sender, EventArgs e)
        {
            timerDiscos.Stop();
            panelInformacoesRede.SendToBack();
            panelDiscos.SendToBack();
            panelInformacoesRAM.BringToFront();
            panelEscolha.Height = butRAM.Height;
            panelEscolha.Top = butRAM.Top;

            //  chartRAM.Series["GraficoRAM"].ChartType = SeriesChartType.Line;
            chartRAM.BackColor = Color.Transparent;
            chartRAM.Legends.Clear();
            if (counter == 0)
            {
                RetornaMaximoMemoriaPermitido();
                RetornaInformacoesMemoria();
                counter++;
            }

            timerRAM.Start();
        }

        private void ComboDiscos_SelectedIndexChanged(object sender, EventArgs e)
        {
            discoSelecionado = comboDiscos.SelectedItem.ToString();
        }

        private void ButDiscos_Click(object sender, EventArgs e)
        {
            timerRAM.Stop();
            panelEscolha.Height = butDiscos.Height;
            panelEscolha.Top = butDiscos.Top;
            comboDiscos.SelectedIndex = 0;
            panelInformacoesRede.SendToBack();
            panelInformacoesRAM.SendToBack();
            panelDiscos.BringToFront();

            timerDiscos.Start();
        }

        private void ButRede_Click(object sender, EventArgs e)
        {
            timerDiscos.Stop();
            panelEscolha.Height = butRede.Height;
            panelEscolha.Top = butRede.Top;
            panelInformacoesRAM.SendToBack();
            panelDiscos.SendToBack();
            panelInformacoesRede.BringToFront();
            timerRede.Start();
        }

        private void ButCPU_Click(object sender, EventArgs e)
        {
            panelEscolha.Height = butCPU.Height;
            panelEscolha.Top = butCPU.Top;
        }

        private void ButClose_Click(object sender, EventArgs e)
        {
            Close();
        }


        #region Controles do monitoramento de Discos
        private void TimerPrincipal_Tick(object sender, EventArgs e)
        {
            foreach (DiscoVO disco in ManipulacaoDisco.RetornaListaDeInformacoesDoDisco())//Criar um método separado para isso
            {
                if (disco.tagDisco == discoSelecionado)
                {
                    if (tamanhoDaPaticaoGB > 1024)
                    {
                        labelEspacoTotal.Text = Math.Round((disco.espacoTotalDoDisco / 1024), 2).ToString() + " TBytes";
                        if (espacoDisponivelGB > 1024)
                        {
                            labelEspacoLivre.Text = Math.Round((disco.espacoLivreNoDisco / 1024), 2).ToString() + " TBytes";
                        }
                        else
                        {
                            labelEspacoLivre.Text = Math.Round(disco.espacoLivreNoDisco, 2).ToString() + " GBytes";
                        }
                        if ((disco.espacoUtilizadoDisco / 1024) > 1)
                        {
                            labelEspacoUtilizado.Text = Math.Round((disco.espacoUtilizadoDisco / 1024), 2).ToString() + " TBytes";
                        }
                    }
                    else
                    {
                        labelEspacoTotal.Text = disco.espacoTotalDoDisco.ToString() + " GBytes";
                        labelEspacoLivre.Text = disco.espacoLivreNoDisco.ToString() + " GBytes";
                        labelEspacoUtilizado.Text = disco.espacoUtilizadoDisco.ToString() + " GBytes";
                    }
                    porcentagemLivre = Math.Truncate((disco.espacoLivreNoDisco / disco.espacoTotalDoDisco) * 100);
                    porcentagemUso = Math.Truncate(100 - porcentagemLivre);
                    chartDiscos.Series.Clear();
                    chartDiscos.Legends.Clear();

                    chartDiscos.Legends.Add(new Legend("Porcentagens"));
                    chartDiscos.Legends["Porcentagens"].LegendStyle = LegendStyle.Column;
                    chartDiscos.Legends["Porcentagens"].Docking = Docking.Right;
                    chartDiscos.Legends["Porcentagens"].Alignment = StringAlignment.Center;
                    chartDiscos.Legends["Porcentagens"].Title = "Porcentagens de utilização do Disco:  " + discoSelecionado;
                    chartDiscos.Legends["Porcentagens"].BorderColor = Color.White;
                    chartDiscos.Legends["Porcentagens"].BackColor = Color.Transparent;
                    chartDiscos.Legends["Porcentagens"].TitleForeColor = Color.WhiteSmoke;

                    chartDiscos.Series.Add("GraficoPizza");
                    chartDiscos.Series["GraficoPizza"].ChartType = SeriesChartType.Doughnut;

                    chartDiscos.Series["GraficoPizza"].Points.AddXY("Livre: " + porcentagemLivre + "%", porcentagemLivre);
                    chartDiscos.Series["GraficoPizza"].Points.AddXY("Em uso: " + porcentagemUso + "%", porcentagemUso);

                    chartDiscos.Series["GraficoPizza"].Legend = "Porcentagens";
                    //chartDiscos.BackColor = Color.Transparent;
                }
            }
        }
        private void ComboDiscos_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            discoSelecionado = comboDiscos.SelectedItem.ToString();
        }
        public void PreencheComboDiscosECarregaPrimeiro()
        {
            foreach (String disco in ManipulacaoDisco.RetornaTagsDiscos())
            {
                comboDiscos.Items.Add(disco);
            }
        }
        #endregion
        #region Monitoramento de Rede
       
        ManipulacaoRede manipulaRede = new ManipulacaoRede();

        private void TimerRede_Tick(object sender, EventArgs e)
        {
            chartUpload.Legends.Clear();
            chartDownload.Legends.Clear();
            chartDownload.Series["GraficoDownload"].ChartType = SeriesChartType.Line;
            chartUpload.Series["GraficoUpload"].ChartType = SeriesChartType.Line;

            RedeVO rede = manipulaRede.RetornaRedeVO();
            if (comboInterfaceDeRede.Items.Count == 0)
            {
                foreach (string interfaceDeRede in rede.NomeDaInterfaceDeRede)
                {
                    comboInterfaceDeRede.Items.Add(interfaceDeRede);
                }
                comboInterfaceDeRede.SelectedIndex = 0;
            }
            textBoxVelocidadeDownload.Text = rede.TaxaDeDownload.ToString() + " KBytes";
            textVelocidadeUpload.Text = rede.TaxaDeUpload.ToString() + " KBytes";
            textPacotesEnviados.Text = rede.PacotesEnviados.ToString() + " pacs";
            textPacotesRecebidos.Text = rede.PacotesRecebidos.ToString() + " pacs";
            textTotalDownload.Text = rede.TotalDeDownload.ToString() + " Kbytes";
            textTotalUpload.Text = rede.TotalDeUpload.ToString() + " Kbytes";
            textVelocidadeMaxima.Text = rede.VelocidadeMaximaInterface.ToString() + " MBytes/s";

            if (chartDownload.Series["GraficoDownload"].Points.Count > 10)
            {
                chartDownload.Series["GraficoDownload"].Points.RemoveAt(0);
                chartDownload.Update();
            }
            chartDownload.Series["GraficoDownload"].Points.AddXY(DateTime.Now.Second + " s", rede.TaxaDeDownload);


            if (chartUpload.Series["GraficoUpload"].Points.Count > 10)
            {
                chartUpload.Series["GraficoUpload"].Points.RemoveAt(0);
                chartUpload.Update();
            }
            chartUpload.Series["GraficoUpload"].Points.AddXY(DateTime.Now.Second + " s", rede.TaxaDeUpload);
            
        }
        #endregion 
        #region Controles do monitoramento da RAM

        private void TimerRAM_Tick(object sender, EventArgs e)
        {
            chartRAM.Legends.Clear();
            ManipulacaoRAM manipulacaoRAM = new ManipulacaoRAM();
            chartRAM.Series["GraficoRAM"].ChartType = SeriesChartType.Line;

            RamVO ramVO = manipulacaoRAM.RetornaRamVO();
            double ramInstalada = ramVO.totalDeRAMInstalada;
            textTotalDeRAM.Text = (Math.Round(ramInstalada, 2)).ToString() + " GBytes";
            //Current memory RAM of the computer.
            MemoriadDisponivel = ramVO.espacoLivreNaRAM;

            textRAMUtilizada.Text = Math.Round(((ramVO.espacoUtilizadoRAM) / 1024), 2).ToString() + " Gbytes";
            if (MemoriadDisponivel >= 1024)
            {
                MemoriadDisponivel = MemoriadDisponivel / 1024;
                textMemoriaDisponivel.Text = Math.Round(MemoriadDisponivel, 2).ToString() + " GBytes";
            }
            else
            {
                textMemoriaDisponivel.Text = MemoriadDisponivel.ToString() + " Mbytes";
            }
            if (chartRAM.Series["GraficoRAM"].Points.Count > 10)
            {
                chartRAM.Series["GraficoRAM"].Points.RemoveAt(0);
                chartRAM.Update();
            }
            chartRAM.Series["GraficoRAM"].Points.AddXY(DateTime.Now.Second + " s", MemoriadDisponivel);
        }
        public void RetornaInformacoesMemoria()
        {
            ManipulacaoRAM manipulacaoRAM = new ManipulacaoRAM();
            List<string> informacoesDaRAM;
            int counter = 0;

            foreach (RamDevicesVO memoriaRam in manipulacaoRAM.RetornaInformacoesMemoria())
            {
                informacoesDaRAM = new List<string>();
                informacoesDaRAM.Add(memoriaRam.tagRAM);
                informacoesDaRAM.Add(memoriaRam.socketDoPente);
                informacoesDaRAM.Add(memoriaRam.capacidadeDoPenteDeMemoria.ToString());
                informacoesDaRAM.Add(memoriaRam.partNumber);
                informacoesDaRAM.Add(memoriaRam.serialNumber);
                informacoesDaRAM.Add(memoriaRam.velocidadeDaMemoria.ToString());
                informacoesDaRAM.Add(memoriaRam.realizaHotSwap.ToString());

                dataGridInformacoesMemoria.Rows.Add(informacoesDaRAM.ToArray());
                counter++;
            }
        }

        public void RetornaMaximoMemoriaPermitido()
        {//posso tirar isso
            double valorMaximoDeRamPermitido;
            string Query = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
            foreach (ManagementObject retorno in searcher.Get())
            {
                if (searcher.Get().Count > 1)
                {
                    MessageBox.Show("Erro na capacidade máxima permitada pela máquina, a pesquisa está devolvendo mais do que um valor");
                }
                valorMaximoDeRamPermitido = Convert.ToDouble(retorno["MaxCapacity"]) / 1048576;
                textMaximoDeMemoria.Text = valorMaximoDeRamPermitido.ToString() + " Gbytes";
            }
        }

        #endregion
        #region 
    }
}

