﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.VOs
{
    /// <summary>
    /// Classe que representa todos os pentes de memória instalados no Computador.
    /// </summary>
    class RamDevicesVO
    {
        public string tagRAM { get; private set; }
        public string socketDoPente { get; private set; }

        public double capacidadeDoPenteDeMemoria { get; private set; }

        public string partNumber { get; private set; }
        public string serialNumber { get; private set; }
        public int velocidadeDaMemoria { get; private set; }
        public bool realizaHotSwap { get; private set; }

        public RamDevicesVO(string tag, string socket, double capadidade, string partNumberMemoria, string numeroDeSerie, int velocidade, bool realizaHotswap )
        {
            tagRAM = tag;
            socketDoPente = socket;
            capacidadeDoPenteDeMemoria = capadidade;
            partNumber = partNumberMemoria;
            serialNumber = numeroDeSerie;
            velocidadeDaMemoria = velocidade;
            realizaHotSwap = realizaHotswap;
        }
}
}
