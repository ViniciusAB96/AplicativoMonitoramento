﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.VOs
{
    class DiscoVO
    {
        public double espacoTotalDoDisco { get; private set; } //eu irei passar para cada disco o tamamnho do mesmo em Gbytes

        public double espacoLivreNoDisco { get; private set; }//em Gbytes
        public double espacoUtilizadoDisco { get; private set; }//em Gbytes
        public string tagDisco { get; private set; }
        public DiscoVO(double espacoTotal, double espacoLivre, double espacoUtilizado, string tagDoDisco)
        {
            espacoUtilizadoDisco = espacoUtilizado;
            espacoTotalDoDisco = espacoTotal;
            espacoLivreNoDisco = espacoLivre;
            tagDisco = tagDoDisco;
        }

    }
}
