﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.VOs
{
    class RedeVO
    {
        public List<string> NomeDaInterfaceDeRede { get; private set; }//posso possuir mais de uma interface de rede no computador
        public double TaxaDeDownload { get; private set; }
        public double TaxaDeUpload { get; private set; }
        public int PacotesEnviados { get; private set; }
        public int PacotesRecebidos { get; private set; }
        public double TotalDeDownload { get; private set; }
        public double TotalDeUpload { get; private set; }
        public int VelocidadeMaximaInterface { get; private set; }


        public RedeVO(List<string> nomeDasInterfaces, double taxaDeDownload, double taxaDeUpload, int pacotesEnviados, int pacotesRecebidos, double totalDeDownload, double totalDeUpload, int velocidadeMaximaInterface)
        {
            NomeDaInterfaceDeRede = nomeDasInterfaces;
            TaxaDeDownload = taxaDeDownload;
            TaxaDeUpload = taxaDeUpload;
            PacotesEnviados = pacotesEnviados;
            PacotesRecebidos = pacotesRecebidos;
            TotalDeDownload = totalDeDownload;
            VelocidadeMaximaInterface = velocidadeMaximaInterface;
            TotalDeUpload = totalDeUpload;
        }


    }
}
