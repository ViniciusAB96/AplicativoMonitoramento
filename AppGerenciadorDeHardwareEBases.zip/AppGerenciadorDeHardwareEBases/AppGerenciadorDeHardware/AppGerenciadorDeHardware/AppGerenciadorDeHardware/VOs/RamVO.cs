﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.VOs
{
    /// <summary>
    /// classe que recebo todas as informações atuais e variaveis da máquina. Essa classe verifica continuamente as informações da RAM que podem variar
    /// </summary>
    class RamVO
    {
        public double totalDeRAMInstalada { get; private set; } //eu irei passar para cada disco o tamamnho do mesmo em Gbytes
        public double totalDeRAMPermitida { get; private set; }//em Gbytes
        public double espacoLivreNaRAM { get; private set; }//em Gbytes
        public double espacoUtilizadoRAM { get; private set; }//em Gbytes
        //veririficar se pode ser necessário a criação de uma lista que contenha a lista de RAM instaladas no computador...
        public RamVO(double ramInstalada, double ramPermitida, double espacolivreRam, double espacoUtilizado)
        {
            totalDeRAMInstalada = ramInstalada;
            totalDeRAMPermitida = ramPermitida;
            espacoLivreNaRAM = espacolivreRam;
            espacoUtilizadoRAM = espacoUtilizado;
        }
    }
}
