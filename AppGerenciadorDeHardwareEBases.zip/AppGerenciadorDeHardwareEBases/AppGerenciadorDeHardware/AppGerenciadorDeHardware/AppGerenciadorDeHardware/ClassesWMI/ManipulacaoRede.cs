﻿using AppGerenciadorDeHardware.VOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.ClassesWMI
{
    class ManipulacaoRede
    {

        private long lngBytesSend  { get; set; }
        private long lngBtyesReceived { get; set; }
        public double totalDeDownload, totalDeUpload;


        public RedeVO RetornaRedeVO()
        {

            int velocidadeMaxima, pacotesEnviados, pacotesRecebidos;
            double velocidadeDeDownload, velocidadeDeUpload;

            NetworkInterface networkInterface = null;
            List<string> listaDasInterfaces = new List<string>();

            foreach (NetworkInterface currentNetworkInterface in NetworkInterface.GetAllNetworkInterfaces())
            {
                listaDasInterfaces.Add(currentNetworkInterface.Name.ToLower());

                if (currentNetworkInterface.Name.ToLower() == "ethernet")
                {
                    networkInterface = currentNetworkInterface;
                    break;
                }
            }
            IPv4InterfaceStatistics interfaceStatistic = networkInterface.GetIPv4Statistics();

            int bytesSentSpeed = (int)(((interfaceStatistic.BytesSent - lngBytesSend) * 10) / 1024);
            int bytesReceivedSpeed = (int)(((interfaceStatistic.BytesReceived - lngBtyesReceived) * 10) / 1024);

            velocidadeMaxima = (int)(networkInterface.Speed / 1000000);

            pacotesEnviados = (int)Math.Truncate((double)interfaceStatistic.UnicastPacketsSent);
            pacotesRecebidos = (int)Math.Truncate((double)interfaceStatistic.UnicastPacketsReceived);
            velocidadeDeUpload = Math.Truncate((double)bytesSentSpeed);
            velocidadeDeDownload = Math.Truncate((double)bytesReceivedSpeed / 1024);
            totalDeDownload += velocidadeDeDownload;
            totalDeUpload += velocidadeDeUpload;

            lngBytesSend = (long)(interfaceStatistic.BytesSent);
            lngBtyesReceived = interfaceStatistic.BytesReceived;
            RedeVO rede = new RedeVO(listaDasInterfaces, velocidadeDeDownload, velocidadeDeUpload, pacotesEnviados, pacotesRecebidos, totalDeDownload, totalDeUpload, velocidadeMaxima);
            return rede;

        }
    }
}
