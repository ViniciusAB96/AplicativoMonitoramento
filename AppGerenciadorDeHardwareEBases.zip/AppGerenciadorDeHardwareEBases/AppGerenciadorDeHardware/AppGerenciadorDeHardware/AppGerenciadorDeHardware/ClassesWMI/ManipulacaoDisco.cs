﻿using AppGerenciadorDeHardware.VOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;


namespace AppGerenciadorDeHardware.ClassesWMI
{
    class ManipulacaoDisco
    {
        private const int VALORPARAGB = 1073741824;
        /// <summary>
        /// Retorna uma lista de Tags de todos os discos presentes no computador
        /// </summary>
        /// <returns></returns>
        public static List<string> RetornaTagsDiscos()
        {
            Querys pesquisas = new Querys();//verificar isso depois
            List<string> discosPresentes = new List<string>();
            ManagementObjectSearcher Discos = new ManagementObjectSearcher(pesquisas.queryRetornaDiscos);
            ManagementObjectCollection retornoDiscos = Discos.Get();//pega o retorno do select que está atuando sobre WMI
            foreach (ManagementObject retorno in retornoDiscos)
            {
                discosPresentes.Add(retorno["DeviceID"].ToString());
            }
            return discosPresentes;
        }
        
        public static List<DiscoVO> RetornaListaDeInformacoesDoDisco()
        {
            Querys pesquisas = new Querys();
            DiscoVO discoPesquisado;
            List<DiscoVO> listaDisco = new List<DiscoVO>();
            string tagParticao = null;
            double tamanhoDaPaticaoGB, espacoDisponivelGB, espacoUtilizadoGB;
            //Querys pesquisas = new Querys();
            ManagementObjectSearcher FisicalMemory = new ManagementObjectSearcher(pesquisas.queryInformacoesDisco);
            ManagementObjectCollection retornoDoDisco = FisicalMemory.Get();//pega o retorno do select que está atuando sobre WMI

            foreach (ManagementObject retorno in retornoDoDisco)
            {
                tamanhoDaPaticaoGB = Math.Round(Convert.ToDouble(retorno["Size"]) / VALORPARAGB, 3);
                espacoDisponivelGB = Math.Round(Convert.ToDouble(retorno["FreeSpace"]) / VALORPARAGB, 3);
                espacoUtilizadoGB = Math.Round((tamanhoDaPaticaoGB - espacoDisponivelGB), 3);
                tagParticao = Convert.ToString(retorno["DeviceID"]);

                discoPesquisado = new DiscoVO(tamanhoDaPaticaoGB, espacoDisponivelGB, espacoUtilizadoGB, tagParticao);
                listaDisco.Add(discoPesquisado);
            }
            return listaDisco;
        }
    }
}
