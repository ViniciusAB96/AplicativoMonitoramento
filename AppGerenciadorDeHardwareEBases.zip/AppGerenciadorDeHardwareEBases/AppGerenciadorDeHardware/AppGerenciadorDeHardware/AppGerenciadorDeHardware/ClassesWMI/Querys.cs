﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.ClassesWMI
{
    class Querys
    {
        private string informacoesDisco = "Select DeviceID, VolumeName, ProviderName, Size, FreeSpace FROM Win32_LogicalDisk";
        public string queryInformacoesDisco
        {
            get
            {
                return informacoesDisco;
            }
        }

        private string retornaDiscos = "Select DeviceID FROM Win32_LogicalDisk where Size != null ";
        public string queryRetornaDiscos
        {
            get
            {
                return retornaDiscos;
            }
        }

        private string queryRetornaInformacoesRAM = "SELECT Tag, DeviceLocator, Capacity, PartNumber, SerialNumber, Speed, HotSwappable FROM Win32_PhysicalMemory";
        public string queryInformacoesRAM
        {
            get
            {
                return queryRetornaInformacoesRAM;
            }
        }

        private string queryRetonaCapacidadeMaximaMemoria = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
        public string QueryRetonaCapacidadeMaximaMemoria
        {
            get
            {
                return queryRetonaCapacidadeMaximaMemoria;
            }
        }
    }
}
