﻿using AppGerenciadorDeHardware.VOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace AppGerenciadorDeHardware.ClassesWMI
{
    class ManipulacaoRAM
    {
        private const int VALORPARAGB = 1073741824;
        public List<RamDevicesVO> RetornaInformacoesMemoria()
        {
            RamDevicesVO ramDevices;
            Querys pesquisas = new Querys();
            List<RamDevicesVO> listaDeHardware = new List<RamDevicesVO>();
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(pesquisas.queryInformacoesRAM);
            //List<RamDevicesVO> informacoesDaRAM;
            //int counter = 0;
            string TagRAM, localDaRAM, partNumber, numeroDeSerie;
            double capacidadeDaRam;
            int velocidadeRAM;
            bool realizaHotSwap;

            foreach (ManagementObject retorno in searcher.Get())
            {
                TagRAM = retorno["Tag"].ToString();
                localDaRAM = retorno["DeviceLocator"].ToString();
                capacidadeDaRam = Math.Round((Convert.ToDouble(retorno["Capacity"]) / VALORPARAGB), 2);
                partNumber = retorno["PartNumber"].ToString();
                numeroDeSerie = retorno["SerialNumber"].ToString();
                velocidadeRAM = Convert.ToInt32(retorno["Speed"]);
                if (retorno["HotSwappable"] == null)
                    realizaHotSwap = false;
                else
                    realizaHotSwap = true;

                ramDevices = new RamDevicesVO(TagRAM, localDaRAM, capacidadeDaRam, partNumber, numeroDeSerie, velocidadeRAM, realizaHotSwap);
                listaDeHardware.Add(ramDevices);
            }
            return listaDeHardware;
        }
        public double RetornaMemoriaDisponivelAtual()
        {
            System.Diagnostics.PerformanceCounter m_memoryCounter = new System.Diagnostics.PerformanceCounter();
            m_memoryCounter.CategoryName = "Memory";
            m_memoryCounter.CounterName = "Available MBytes";
            return m_memoryCounter.RawValue;
        }
        public RamVO RetornaRamVO()
        {
            double sizeCapacidade = 0;

            double capacidadeTotal = 0, valorMaximoDeRamPermitido = 0, espacoLivreNaRAM, espacoUtilizadoNaRAM;
            RamVO ramVO;
            Querys pesquisas = new Querys();
            foreach (RamDevicesVO memoriaInstalada in RetornaInformacoesMemoria())
            {
                sizeCapacidade += memoriaInstalada.capacidadeDoPenteDeMemoria;
            }

            capacidadeTotal = sizeCapacidade;
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(pesquisas.QueryRetonaCapacidadeMaximaMemoria);
            foreach (ManagementObject retorno in searcher.Get())
            {
                if (searcher.Get().Count != 1)
                {
                    throw new Exception("Erro na capacidade máxima permitada pela máquina, a pesquisa está devolvendo mais do que um valor");
                }
                valorMaximoDeRamPermitido = Math.Round(Convert.ToDouble(retorno["MaxCapacity"]),1);// valor em kbytes

            }
            espacoLivreNaRAM = RetornaMemoriaDisponivelAtual();
            espacoUtilizadoNaRAM = ((capacidadeTotal*1024) - espacoLivreNaRAM);
            valorMaximoDeRamPermitido = Math.Round((Convert.ToDouble(valorMaximoDeRamPermitido) / 1048576), 1);
            ramVO = new RamVO(capacidadeTotal, valorMaximoDeRamPermitido, espacoLivreNaRAM, espacoUtilizadoNaRAM);
            return ramVO;
        }
    }
}
