﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;
using System.Net.NetworkInformation;

namespace ProcessorName
{
    class Program
    {


        static void Main(string[] args)
        {
            const int VALORPARAGB = 1073741824;
            OperatingSystem os = System.Environment.OSVersion;

            ManagementObjectSearcher s2 = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor");

            foreach (ManagementObject mo in s2.Get())
                Console.WriteLine("Processador: {0}", mo["Name"]);


            ManagementObjectSearcher objMOS = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM  Win32_BaseBoard");
            try
            {

                foreach (ManagementObject objManagemnet in objMOS.Get())
                {

                    Console.WriteLine("======================================================================");
                    Console.WriteLine("                Detalhes da Placa Mãe                                 ");
                    Console.WriteLine("======================================================================");
                    Console.WriteLine("Caption             :" + objManagemnet.GetPropertyValue("Caption").ToString());
                    Console.WriteLine("CreationClassName   :" + objManagemnet.GetPropertyValue("CreationClassName").ToString());
                    Console.WriteLine("Description         :" + objManagemnet.GetPropertyValue("Description").ToString());
                    Console.WriteLine("InstallDate         :" + Convert.ToDateTime(objManagemnet.GetPropertyValue("InstallDate")));
                    Console.WriteLine("Manufacturer        :" + objManagemnet.GetPropertyValue("Manufacturer").ToString());
                    Console.WriteLine("Model               :" + Convert.ToString(objManagemnet.GetPropertyValue("Model")));
                    Console.WriteLine("Name                :" + objManagemnet.GetPropertyValue("Name").ToString());
                    Console.WriteLine("PartNumber          :" + Convert.ToInt32(objManagemnet.GetPropertyValue("PartNumber")));
                    Console.WriteLine("PoweredOn           :" + objManagemnet.GetPropertyValue("PoweredOn").ToString());
                    Console.WriteLine("Product             :" + objManagemnet.GetPropertyValue("Product").ToString());
                    Console.WriteLine("SerialNumber        :" + objManagemnet.GetPropertyValue("SerialNumber").ToString());
                    Console.WriteLine("SKU                 :" + Convert.ToString(objManagemnet.GetPropertyValue("SKU")));
                    Console.WriteLine("Status              :" + Convert.ToString(objManagemnet.GetPropertyValue("Status")));
                    Console.WriteLine("Tag                 :" + Convert.ToString(objManagemnet.GetPropertyValue("Tag")));
                    Console.WriteLine("Version             :" + Convert.ToString(objManagemnet.GetPropertyValue("Version")));
                    Console.WriteLine("Weight              :" + Convert.ToString(objManagemnet.GetPropertyValue("Weight")));
                    Console.WriteLine("Height              :" + Convert.ToString(objManagemnet.GetPropertyValue("Height")));
                    Console.WriteLine("PoweredOn           :" + Convert.ToString(objManagemnet.GetPropertyValue("PoweredOn")));
                    //   Console.WriteLine("Ram Installed: {0:N0} bytes", objManagemnet.SystemProperties);

                }
                //Memória fisica do computador RAM
                string Query = "SELECT MaxCapacity FROM Win32_PhysicalMemoryArray";
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(Query);
                foreach (ManagementObject WniPART in searcher.Get())
                {
                    UInt32 SizeinKB = Convert.ToUInt32(WniPART.Properties["MaxCapacity"].Value);
                    UInt32 SizeinMB = SizeinKB / 1024;
                    UInt32 SizeinGB = SizeinMB / 1024;
                    Console.WriteLine("Size in KB: {0}, Size in MB: {1}, Size in GB: {2}", SizeinKB, SizeinMB, SizeinGB + Environment.NewLine);
                }

                //Current memory RAM of the computer.
                Console.WriteLine("Memória disponível para uso, sendo que essa memória é a memória RAM atual");
                System.Diagnostics.PerformanceCounter m_memoryCounter = new System.Diagnostics.PerformanceCounter();
                System.Diagnostics.PerformanceCounter m_CPUCounter = new System.Diagnostics.PerformanceCounter();

                m_memoryCounter.CategoryName = "Memory";
                m_memoryCounter.CounterName = "Available MBytes";

                Console.WriteLine(m_memoryCounter.NextValue());


                Console.WriteLine("Frequencia atual do processador");
                System.Diagnostics.PerformanceCounter m_frequenciaCPU = new System.Diagnostics.PerformanceCounter("Processor", "% Processor Time", "_Total");
                Console.WriteLine(m_frequenciaCPU.NextValue());

                Console.WriteLine("Verificando a frequencia do processador");
                Console.WriteLine("@#$%¨&*()@#$%¨&*(@#$%¨&*(@!#$%¨&*(");
                

                // Usado para saber a porcentagem da utilização da CPU/ processador.   


                Console.WriteLine(Environment.NewLine);
                Console.WriteLine("_------------____------------------------______----------------------------______-----------------");
                Console.WriteLine(Environment.NewLine);

                ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("SELECT maxclockspeed, datawidth, name, manufacturer FROM Win32_Processor");

                ManagementObjectCollection objCol = searcher2.Get();
                foreach (ManagementObject mgtObject in objCol)
                {
                    Console.WriteLine("Retorno de algumas funções da CPU, dentre elas o máximo clockspeed");
                    Console.Write("Máximo clock do processador: " + mgtObject["maxclockspeed"].ToString() + Environment.NewLine);
                    Console.Write("DataWidth: " + mgtObject["datawidth"].ToString() + " Bits" + Environment.NewLine);
                    Console.Write("Nome do computador: " + mgtObject["name"].ToString() + Environment.NewLine);
                    Console.Write("Fabricante: " + mgtObject["manufacturer"].ToString() + Environment.NewLine);
                }

                ///Apresenta a temperatura como ela é lida pela CPU, ou seja na base 10 e em Kelvin
                ManagementClass processClass = new ManagementClass(@"\root\cimv2:Win32_TemperatureProbe");
                double temperatura;
                foreach (ManagementObject service in processClass.GetInstances())
                {
                    Console.WriteLine("Temperatura da  CPU e GPU na sequencia");
                    Console.WriteLine("Valor da temperaturan vida do TemperaturaProbe: " + service.GetPropertyValue("Accuracy"));


                    temperatura = Convert.ToInt32(service.GetPropertyValue("Accuracy"));
                    Console.WriteLine("Temperatura: " + ((temperatura / 100) - 273.15) + "ºC");
                }



                //Me retorna todos as partições presentes no computador, inclusive a partição que não possui volume, ou seja a partição E, do leitor de CD/DVD
                ManagementObjectSearcher FisicalMemory = new ManagementObjectSearcher("Select DeviceID, VolumeName, ProviderName, Size, FreeSpace FROM Win32_LogicalDisk where Size != null ");

                ManagementObjectCollection objetoRetorno = FisicalMemory.Get();
                //string escreveTela;

                foreach (ManagementObject retorno in objetoRetorno)
                {
                    double tamanhoDaPaticaoGB = Math.Round(Convert.ToDouble(retorno["Size"]) / VALORPARAGB, 3);
                    double espacoDisponivelGB = Math.Round(Convert.ToDouble(retorno["FreeSpace"]) / VALORPARAGB, 3);

                    Console.WriteLine("Storage do computador");
                    Console.WriteLine("ID da partição: " + retorno["DeviceID"].ToString() + Environment.NewLine);
                    if (retorno["ProviderName"] != null)
                    {
                        Console.WriteLine("Espaço disponível: " + retorno["ProviderName"].ToString() + Environment.NewLine);
                    }
                    Console.WriteLine("Nome do Volume: " + retorno["VolumeName"].ToString() + Environment.NewLine);
                    Console.WriteLine("Tamanho da partição: " + tamanhoDaPaticaoGB + " GB" + Environment.NewLine);
                    Console.WriteLine("Espaço disponível: " + espacoDisponivelGB + " GB" + Environment.NewLine);

                }


               /*
                ManagementObjectSearcher networkAdapterSearcher = new ManagementObjectSearcher("root\\cimv2", "select * from Win32_NetworkAdapterConfiguration");
                ManagementObjectCollection objectCollection = networkAdapterSearcher.Get();

                Console.WriteLine("There are {0} network adapaters: ", objectCollection.Count);

                foreach (ManagementObject networkAdapter in objectCollection)
                {
                    
                    PropertyDataCollection networkAdapterProperties = networkAdapter.Properties;
                    foreach (PropertyData networkAdapterProperty in networkAdapterProperties)
                    {
                        if (networkAdapterProperty.Value != null)
                        {
                            Console.WriteLine("Network adapter property name: {0}", networkAdapterProperty.Name);
                            Console.WriteLine("Network adapter property value: {0}", networkAdapterProperty.Value);
                        }
                    }
                    Console.WriteLine("---------------------------------------");
                }*/



                /*
                NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces();
                foreach (NetworkInterface adapter in adapters)
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();
                    IPv4InterfaceStatistics stats = adapter.GetIPv4Statistics();
                    Console.WriteLine(adapter.Description);
                    Console.WriteLine("     Speed .................................: {0}",
                        adapter.Speed);
                    Console.WriteLine("     Output queue length....................: {0}",
                        stats.OutputQueueLength);
                }
                */


            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("Caiu no erro");
            }
            Console.ReadKey();
        }

    }


}


